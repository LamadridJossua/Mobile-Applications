package com.example.whowroteitv2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity
        implements LoaderManager.LoaderCallbacks<String> {

    // Member variables for the UI elements
    private EditText mBookInput;
    private TextView mTitleText;
    private TextView mAuthorText;

    // Constants for the loader ID and bundle keys
    private static final int BOOK_LOADER_ID = 1;
    private static final String QUERY_STRING = "queryString";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the UI elements
        mBookInput = findViewById(R.id.bookInput);
        mTitleText = findViewById(R.id.titleText);
        mAuthorText = findViewById(R.id.authorText);

        // Initialize the loader if it exists (e.g. after a configuration change)
        if (LoaderManager.getInstance(this).getLoader(BOOK_LOADER_ID) != null) {
            LoaderManager.getInstance(this).initLoader(BOOK_LOADER_ID, null, this);
        }
    }

    /**
     * Called when the search button is clicked
     * @param view The button view
     */
    public void searchBooks(View view) {
        // Get the search string from the input field
        String queryString = mBookInput.getText().toString();

        // Hide the keyboard when the button is clicked
        InputMethodManager inputManager = (InputMethodManager)
                getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputManager != null) {
            inputManager.hideSoftInputFromWindow(view.getWindowToken(),
                    InputMethodManager.HIDE_NOT_ALWAYS);
        }

        // Check the network connection and query string
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = null;
        if (connMgr != null) {
            networkInfo = connMgr.getActiveNetworkInfo();
        }

        if (networkInfo != null && networkInfo.isConnected()
                && queryString.length() != 0) {
            // Start the loader with the query string
            Bundle queryBundle = new Bundle();
            queryBundle.putString(QUERY_STRING, queryString);
            LoaderManager.getInstance(this).restartLoader(BOOK_LOADER_ID, queryBundle, this);

            // Update the TextView to "Loading..."
            mTitleText.setText(R.string.loading);
            mAuthorText.setText("");
        } else {
            if (queryString.length() == 0) {
                mTitleText.setText(R.string.no_search_term);
                mAuthorText.setText("");
            } else {
                mTitleText.setText(R.string.no_network);
                mAuthorText.setText("");
            }
        }
    }

    /**
     * Called when a new Loader needs to be created
     */
    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {
        String queryString = "";

        if (args != null) {
            queryString = args.getString(QUERY_STRING);
        }

        return new com.example.whowroteitv2.BookLoader(this, queryString);
    }

    /**
     * Called when a Loader has finished loading its data
     */
    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        // Log the raw data received from the loader
        Log.d("MainActivity", "Received data: " + data);
        try {
            // Check if we received valid data
            if (data == null) {
                mTitleText.setText(R.string.no_results);
                mAuthorText.setText("");
                return;
            }

            // Parse the JSON response
            JSONObject jsonObject = new JSONObject(data);

            // Check if the response contains items
            if (!jsonObject.has("items")) {
                mTitleText.setText(R.string.no_results);
                mAuthorText.setText("");
                return;
            }

            // Get the "items" array
            JSONArray itemsArray = jsonObject.getJSONArray("items");

            // Variables to hold the data
            int i = 0;
            String title = null;
            String authors = null;

            // Look for results with both a title and author
            while (i < itemsArray.length() && (authors == null && title == null)) {
                // Get the current item
                JSONObject book = itemsArray.getJSONObject(i);
                JSONObject volumeInfo = book.getJSONObject("volumeInfo");

                // Try to get the title and authors
                try {
                    title = volumeInfo.getString("title");
                    JSONArray authorsArray = volumeInfo.getJSONArray("authors");
                    StringBuilder authorsBuilder = new StringBuilder();

                    // Process each author in the array
                    for (int j = 0; j < authorsArray.length(); j++) {
                        if (j > 0) {
                            authorsBuilder.append(", ");
                        }
                        authorsBuilder.append(authorsArray.getString(j));
                    }

                    authors = authorsBuilder.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                // Move to the next item
                i++;
            }

            // If both are found, update the UI
            if (title != null && authors != null) {
                mTitleText.setText(title);
                mAuthorText.setText(authors);
            } else {
                mTitleText.setText(R.string.no_results);
                mAuthorText.setText("");
            }

        } catch (Exception e) {
            // Log the error
            e.printStackTrace();

            // Update the UI to show no results
            mTitleText.setText(R.string.no_results);
            mAuthorText.setText("");
        }
    }

    /**
     * Called when a previously created loader is being reset
     */
    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {
        // Not used in this app
    }
}