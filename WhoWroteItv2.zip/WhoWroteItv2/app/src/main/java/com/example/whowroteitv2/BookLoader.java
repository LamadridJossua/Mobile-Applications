package com.example.whowroteitv2;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.loader.content.AsyncTaskLoader;

public class BookLoader extends AsyncTaskLoader<String> {

    // Query string used for the API call
    private String mQueryString;

    /**
     * Constructor for the BookLoader
     * @param context The application context
     * @param queryString The book search query string
     */
    public BookLoader(@NonNull Context context, String queryString) {
        super(context);
        mQueryString = queryString;
    }

    /**
     * Called when the loader starts loading
     */
    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad(); // Force an asynchronous load
    }

    /**
     * Performs the API call in the background
     * @return The JSON response from the API
     */
    @Nullable
    @Override
    public String loadInBackground() {
        return NetworkUtils.getBookInfo(mQueryString);
    }
}