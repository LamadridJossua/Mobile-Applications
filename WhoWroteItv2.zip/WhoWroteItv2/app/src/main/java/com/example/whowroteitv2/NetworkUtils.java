package com.example.whowroteitv2;

import android.net.Uri;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class NetworkUtils {
    private static final String LOG_TAG = NetworkUtils.class.getSimpleName();

    // Base URL for Books API
    private static final String BOOK_BASE_URL = "https://www.googleapis.com/books/v1/volumes?";
    // Parameter for the search string
    private static final String QUERY_PARAM = "q";
    // Parameter that limits search results
    private static final String MAX_RESULTS = "maxResults";
    // Parameter to filter by print type
    private static final String PRINT_TYPE = "printType";

    /**
     * Method to get book information from the Google Books API.
     * @param queryString The book to search for
     * @return The JSON response from the API
     */
    static String getBookInfo(String queryString) {
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;
        String bookJSONString = null;

        try {
            // Build the URI for the Books API query
            Uri builtURI = Uri.parse(BOOK_BASE_URL).buildUpon()
                    .appendQueryParameter(QUERY_PARAM, queryString)
                    .appendQueryParameter(MAX_RESULTS, "10")
                    .appendQueryParameter(PRINT_TYPE, "books")
                    .build();

            // Convert the URI to a URL
            URL requestURL = new URL(builtURI.toString());
            
            // Log the request URL for debugging
            Log.d(LOG_TAG, "Request URL: " + requestURL.toString());

            // Open the URL connection
            urlConnection = (HttpURLConnection) requestURL.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setConnectTimeout(15000); /* 15 seconds */
            urlConnection.setReadTimeout(10000); /* 10 seconds */
            urlConnection.connect();

            // Get the input stream
            InputStream inputStream = urlConnection.getInputStream();

            // Create a buffered reader from that input stream
            reader = new BufferedReader(new InputStreamReader(inputStream));

            // Use a StringBuilder to hold the incoming response
            StringBuilder builder = new StringBuilder();

            // Read the input line by line
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
                // Add a newline character for debugging
                builder.append("\n");
            }

            // Return null if the response is empty
            if (builder.length() == 0) {
                return null;
            }

            // Convert the StringBuilder to a String
            bookJSONString = builder.toString();
            
            // Log the JSON response for debugging
            Log.d(LOG_TAG, "JSON Response: " + bookJSONString);

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            // Close the connection and reader
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return bookJSONString;
    }
}