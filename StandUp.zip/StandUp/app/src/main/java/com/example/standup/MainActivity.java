package com.example.standup;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.AlarmClock;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    // Notification ID
    private static final int NOTIFICATION_ID = 0;

    // Notification channel ID
    private static final String PRIMARY_CHANNEL_ID = "primary_notification_channel";

    // Member variable for the notification manager
    private NotificationManager mNotificationManager;

    // Member variables for the alarm
    private AlarmManager alarmManager;
    private PendingIntent notifyPendingIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize notification manager
        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // Set up the ToggleButton
        ToggleButton alarmToggle = findViewById(R.id.alarmToggle);

        // Initialize the AlarmManager
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        // Create the notification channel
        createNotificationChannel();

        // Set up the intent for the AlarmReceiver
        Intent notifyIntent = new Intent(this, AlarmReceiver.class);

        // Check if alarm is already set
        boolean alarmUp = (PendingIntent.getBroadcast(
                this, NOTIFICATION_ID, notifyIntent, 
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE) != null);

        // Set the state of the toggle based on whether the alarm is already set
        alarmToggle.setChecked(alarmUp);

        // Create the PendingIntent for the alarm
        notifyPendingIntent = PendingIntent.getBroadcast(
                this, NOTIFICATION_ID, notifyIntent, 
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                
        // Set up animations for the UI elements
        setupAnimations();

        // Set the OnCheckedChangeListener for the toggle button
        alarmToggle.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                        if (isChecked) {
                            // Show a toast message that the alarm is turned on
                            Toast.makeText(MainActivity.this, getString(R.string.alarm_on_toast),
                                    Toast.LENGTH_SHORT).show();

                            // Set the device alarm
                            Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                            alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Time to Stand Up!");
                            alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, 0);
                            alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                            alarmIntent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                            
                            // Check if there's an app that can handle this intent
                            if (alarmIntent.resolveActivity(getPackageManager()) != null) {
                                startActivity(alarmIntent);
                            } else {
                                Toast.makeText(MainActivity.this, 
                                    "No alarm app found on your device", 
                                    Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // Show a toast message that the alarm is turned off
                            Toast.makeText(MainActivity.this, getString(R.string.alarm_off_toast),
                                    Toast.LENGTH_SHORT).show();

                            // Cancel the alarm and notification if the toggle is turned off
                            if (alarmManager != null) {
                                alarmManager.cancel(notifyPendingIntent);
                            }

                            // Cancel any notifications that might be showing
                            mNotificationManager.cancelAll();
                        }
                    }
                });
    }

    /**
     * Creates a Notification channel, for OREO and higher.
     */
    public void createNotificationChannel() {
        // Check if the Android Version is greater than or equal to Oreo
        if (android.os.Build.VERSION.SDK_INT >=
                android.os.Build.VERSION_CODES.O) {

            // Create the NotificationChannel with all the parameters
            NotificationChannel notificationChannel = new NotificationChannel(
                    PRIMARY_CHANNEL_ID,
                    getString(R.string.stand_up_notification),
                    NotificationManager.IMPORTANCE_HIGH);

            // Set the description of the channel
            notificationChannel.setDescription(getString(R.string.notification_channel_description));

            // Configure additional channel settings
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);

            // Register the channel with the system
            mNotificationManager.createNotificationChannel(notificationChannel);
        }
    }
    
    /**
     * Sets up animations for the UI elements to create a more engaging experience
     */
    private void setupAnimations() {
        // Get references to UI elements
        ImageView headerImage = findViewById(R.id.headerImage);
        TextView titleText = findViewById(R.id.titleText);
        TextView descriptionText = findViewById(R.id.descriptionText);
        
        // Load animations
        Animation fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
        Animation slideUp = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);
        
        // Set animation durations
        fadeIn.setDuration(1000);
        slideUp.setDuration(800);
        
        // Apply animations with delays for sequence effect
        headerImage.startAnimation(fadeIn);
        
        // Apply animation to title with delay
        titleText.setAlpha(0f);
        titleText.postDelayed(() -> {
            titleText.setAlpha(1f);
            titleText.startAnimation(fadeIn);
        }, 300);
        
        // Apply animation to description with delay
        descriptionText.setAlpha(0f);
        descriptionText.postDelayed(() -> {
            descriptionText.setAlpha(1f);
            descriptionText.startAnimation(fadeIn);
        }, 600);
    }
}