package com.example.rldvm;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

/**
 * ViewModel that provides data to the UI and survives configuration changes.
 * Acts as a communication center between the Repository and the UI.
 */
public class WordViewModel extends AndroidViewModel {

    private WordRepository mRepository;
    private final LiveData<List<Word>> mAllWords;

    // Constructor that gets reference to the repository and gets all words
    public WordViewModel(Application application) {
        super(application);
        mRepository = new WordRepository(application);
        mAllWords = mRepository.getAllWords();
    }

    // Getter method for all words that hides implementation from the UI
    LiveData<List<Word>> getAllWords() {
        return mAllWords;
    }

    // Wrapper for the Repository's insert method
    // This ensures the UI has a clean API
    public void insert(Word word) {
        mRepository.insert(word);
    }
    
    // Wrapper for the Repository's delete method
    // This ensures the UI has a clean API
    public void delete(Word word) {
        mRepository.delete(word);
    }
}
