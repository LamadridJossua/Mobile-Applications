package com.example.rldvm;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

/**
 * Data Access Object (DAO) for the Word entity.
 * This interface defines methods for accessing the database.
 */
@Dao
public interface WordDao {

    // Insert a word into the database.
    // OnConflictStrategy.IGNORE: ignore a new word if it's already in the database
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Word word);

    // Delete a specific word from the database
    @Delete
    void delete(Word word);

    // Delete all words from the database
    @Query("DELETE FROM word_table")
    void deleteAll();

    // Get all words from the database ordered alphabetically
    @Query("SELECT * FROM word_table ORDER BY word ASC")
    LiveData<List<Word>> getAllWords();
}
