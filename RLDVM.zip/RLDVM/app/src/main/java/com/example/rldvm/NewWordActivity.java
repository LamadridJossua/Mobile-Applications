package com.example.rldvm;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Activity for entering a new word.
 */
public class NewWordActivity extends AppCompatActivity {

    public static final String EXTRA_REPLY = "com.example.android.wordlistsql.REPLY";

    private TextInputEditText mEditWordView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_word);
        
        // Set up toolbar with back button
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        
        mEditWordView = findViewById(R.id.edit_word);

        final MaterialButton button = findViewById(R.id.button_save);
        
        // Set click listener for the save button
        button.setOnClickListener(view -> {
            Intent replyIntent = new Intent();
            
            // Check if the EditText is empty
            if (TextUtils.isEmpty(mEditWordView.getText())) {
                // Return an empty result if the field is empty
                setResult(RESULT_CANCELED, replyIntent);
            } else {
                // Get the word from the EditText
                String word = mEditWordView.getText().toString();
                // Put the word in the intent
                replyIntent.putExtra(EXTRA_REPLY, word);
                // Set the result to OK
                setResult(RESULT_OK, replyIntent);
            }
            // Close the activity
            finish();
        });
    }
    
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle the back button
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
