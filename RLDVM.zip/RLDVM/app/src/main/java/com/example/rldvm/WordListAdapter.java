package com.example.rldvm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter for the RecyclerView that displays a list of words.
 */
public class WordListAdapter extends RecyclerView.Adapter<WordListAdapter.WordViewHolder> {

    private final LayoutInflater mInflater;
    private List<Word> mWords; // Cached copy of words
    private OnWordClickListener mListener;

    // Interface for click events
    public interface OnWordClickListener {
        void onDeleteClick(Word word);
    }

    // Constructor that takes a context
    WordListAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
    }

    // Set the click listener
    public void setOnWordClickListener(OnWordClickListener listener) {
        this.mListener = listener;
    }

    // Create new views (invoked by the layout manager)
    @NonNull
    @Override
    public WordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recyclerview_item, parent, false);
        return new WordViewHolder(itemView, mListener);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull WordViewHolder holder, int position) {
        if (mWords != null) {
            Word current = mWords.get(position);
            holder.wordItemView.setText(current.getWord());
            holder.bind(current);
        } else {
            // Covers the case of data not being ready yet
            holder.wordItemView.setText("No Word");
        }
    }

    // Update the cached copy of the words and notify adapter of change
    void setWords(List<Word> words) {
        mWords = words;
        notifyDataSetChanged();
    }

    // Get a word at a specific position
    public Word getWordAtPosition(int position) {
        return mWords.get(position);
    }

    // getItemCount() is called many times, and when it is first called,
    // mWords has not been updated (means initially, it's null, and we can't return null)
    @Override
    public int getItemCount() {
        if (mWords != null)
            return mWords.size();
        else return 0;
    }

    // ViewHolder class that represents each row in the RecyclerView
    class WordViewHolder extends RecyclerView.ViewHolder {
        private final TextView wordItemView;
        private final ImageButton deleteButton;
        private Word currentWord;

        private WordViewHolder(View itemView, final OnWordClickListener listener) {
            super(itemView);
            wordItemView = itemView.findViewById(R.id.textView);
            deleteButton = itemView.findViewById(R.id.delete_button);
            
            // Set click listener for delete button
            deleteButton.setOnClickListener(v -> {
                if (listener != null && currentWord != null) {
                    listener.onDeleteClick(currentWord);
                }
            });
        }
        
        // Bind the current word to this ViewHolder
        void bind(Word word) {
            this.currentWord = word;
        }
    }
}
