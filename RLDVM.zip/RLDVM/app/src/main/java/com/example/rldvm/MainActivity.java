package com.example.rldvm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class MainActivity extends AppCompatActivity implements WordListAdapter.OnWordClickListener {

    private WordViewModel mWordViewModel;
    private TextView emptyView;
    private View mainLayout;
    public static final int NEW_WORD_ACTIVITY_REQUEST_CODE = 1;

    // ActivityResultLauncher for handling the result from NewWordActivity
    private final ActivityResultLauncher<Intent> newWordActivityLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null) {
                        Word word = new Word(data.getStringExtra(NewWordActivity.EXTRA_REPLY));
                        mWordViewModel.insert(word);
                        Toast.makeText(getApplicationContext(), "Word saved!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(
                            getApplicationContext(),
                            R.string.empty_not_saved,
                            Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        // Get reference to main layout for Snackbar
        mainLayout = findViewById(R.id.main);
        
        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        
        // Set up window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get reference to empty view
        emptyView = findViewById(R.id.empty_view);
        
        // Set up RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        final WordListAdapter adapter = new WordListAdapter(this);
        adapter.setOnWordClickListener(this); // Set this activity as the click listener
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set up ViewModel
        mWordViewModel = new ViewModelProvider(this).get(WordViewModel.class);
        
        // Add an observer on the LiveData returned by getAllWords
        // The onChanged() method fires when the observed data changes and the activity is in the foreground
        mWordViewModel.getAllWords().observe(this, words -> {
            // Update the cached copy of the words in the adapter
            adapter.setWords(words);
            
            // Show empty view if list is empty
            if (words != null && words.isEmpty()) {
                recyclerView.setVisibility(View.GONE);
                emptyView.setVisibility(View.VISIBLE);
            } else {
                recyclerView.setVisibility(View.VISIBLE);
                emptyView.setVisibility(View.GONE);
            }
        });

        // Set up FAB to open NewWordActivity
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, NewWordActivity.class);
            newWordActivityLauncher.launch(intent);
        });
    }
    
    @Override
    public void onDeleteClick(Word word) {
        // Delete the word
        mWordViewModel.delete(word);
        
        // Show a snackbar with the deletion message
        Snackbar.make(mainLayout, R.string.word_deleted, Snackbar.LENGTH_SHORT).show();
    }
}