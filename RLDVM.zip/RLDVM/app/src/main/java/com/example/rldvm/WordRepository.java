package com.example.rldvm;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

/**
 * Repository class that abstracts access to multiple data sources.
 * This provides a clean API for the rest of the app to access data.
 */
public class WordRepository {

    private WordDao mWordDao;
    private LiveData<List<Word>> mAllWords;

    // Constructor that gets a handle to the database and initializes member variables
    WordRepository(Application application) {
        WordRoomDatabase db = WordRoomDatabase.getDatabase(application);
        mWordDao = db.wordDao();
        mAllWords = mWordDao.getAllWords();
    }

    // Wrapper for getAllWords method from the DAO
    // Room executes all queries on a separate thread
    // Observed LiveData will notify the observer when the data has changed
    LiveData<List<Word>> getAllWords() {
        return mAllWords;
    }

    // Wrapper for insert method from the DAO
    // Must be called on a non-UI thread or app will crash
    void insert(Word word) {
        WordRoomDatabase.databaseWriteExecutor.execute(() -> {
            mWordDao.insert(word);
        });
    }
    
    // Wrapper for delete method from the DAO
    // Must be called on a non-UI thread or app will crash
    void delete(Word word) {
        WordRoomDatabase.databaseWriteExecutor.execute(() -> {
            mWordDao.delete(word);
        });
    }
}
