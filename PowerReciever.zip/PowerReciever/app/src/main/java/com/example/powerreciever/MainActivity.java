package com.example.powerreciever;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import java.io.File;

public class MainActivity extends AppCompatActivity {

    // Custom broadcast action string
    private static final String ACTION_CUSTOM_BROADCAST =
            "com.example.powerreciever.ACTION_CUSTOM_BROADCAST";

    // Declare the CustomReceiver instance
    private CustomReceiver mReceiver = new CustomReceiver();
    
    // UI elements
    private ImageView powerStatusIcon;
    private TextView powerStatusText;
    private TextView folderStatusText;
    private TextView broadcastStatusText;
    private EditText folderPathInput;
    
    // Power status broadcast receiver
    private BroadcastReceiver powerStatusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null) {
                updatePowerStatusUI(action);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize UI elements
        powerStatusIcon = findViewById(R.id.power_status_icon);
        powerStatusText = findViewById(R.id.power_status_text);
        folderStatusText = findViewById(R.id.folder_status_text);
        broadcastStatusText = findViewById(R.id.broadcast_status_text);
        folderPathInput = findViewById(R.id.folder_path_input);

        // Create IntentFilter for power broadcasts
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_POWER_CONNECTED);
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED);

        // Register the receiver using the activity context
        this.registerReceiver(mReceiver, filter);
        
        // Register power status receiver
        this.registerReceiver(powerStatusReceiver, filter);

        // Register the receiver for custom broadcasts
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(mReceiver,
                        new IntentFilter(ACTION_CUSTOM_BROADCAST));
        
        // Check initial power connection status
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, ifilter);
        if (batteryStatus != null) {
            int status = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1);
            boolean isCharging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == android.os.BatteryManager.BATTERY_STATUS_FULL;
            updatePowerStatusUI(isCharging ? Intent.ACTION_POWER_CONNECTED : Intent.ACTION_POWER_DISCONNECTED);
        }
    }

    @Override
    protected void onDestroy() {
        // Unregister the system broadcast receivers
        this.unregisterReceiver(mReceiver);
        this.unregisterReceiver(powerStatusReceiver);

        // Unregister the local broadcast receiver
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mReceiver);

        super.onDestroy();
    }

    /**
     * Click event handler for the Send Custom Broadcast button
     * @param view The view (Button) that was clicked
     */
    public void sendCustomBroadcast(View view) {
        // Create a new Intent with the custom action
        Intent customBroadcastIntent = new Intent(ACTION_CUSTOM_BROADCAST);

        // Send the broadcast using LocalBroadcastManager
        LocalBroadcastManager.getInstance(this)
                .sendBroadcast(customBroadcastIntent);
        
        // Update the broadcast status text
        broadcastStatusText.setText(R.string.broadcast_sent);
        broadcastStatusText.setVisibility(View.VISIBLE);
    }
    
    /**
     * Click event handler for the Check Folder button
     * @param view The view (Button) that was clicked
     */
    public void checkFolder(View view) {
        String folderPath = folderPathInput.getText().toString().trim();
        
        if (folderPath.isEmpty()) {
            Toast.makeText(this, "Please enter a folder path", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Check if the folder exists
        File folder = new File(folderPath);
        boolean folderExists = folder.exists() && folder.isDirectory();
        
        // Update the folder status text
        folderStatusText.setText(folderExists ? R.string.folder_exists : R.string.folder_does_not_exist);
        folderStatusText.setTextColor(getResources().getColor(
                folderExists ? R.color.success_green : R.color.error_red));
        folderStatusText.setVisibility(View.VISIBLE);
    }
    
    /**
     * Updates the power status UI based on the power connection state
     * @param action The power connection action
     */
    private void updatePowerStatusUI(String action) {
        if (action.equals(Intent.ACTION_POWER_CONNECTED)) {
            powerStatusIcon.setImageResource(R.drawable.ic_power_connected);
            powerStatusText.setText(R.string.power_connected);
            powerStatusText.setTextColor(getResources().getColor(R.color.success_green));
        } else if (action.equals(Intent.ACTION_POWER_DISCONNECTED)) {
            powerStatusIcon.setImageResource(R.drawable.ic_power_disconnected);
            powerStatusText.setText(R.string.power_disconnected);
            powerStatusText.setTextColor(getResources().getColor(R.color.error_red));
        }
    }
}