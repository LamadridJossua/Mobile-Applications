package com.example.notifyme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    // Constants for the notification channel
    private static final String PRIMARY_CHANNEL_ID = "primary_notification_channel";

    // Constant for the notification ID
    private static final int NOTIFICATION_ID = 0;

    // Constant for the action button update notification
    private static final String ACTION_UPDATE_NOTIFICATION =
            "com.example.notifyme.ACTION_UPDATE_NOTIFICATION";

    // Member variables for buttons
    private Button mNotifyButton;
    private Button mUpdateButton;
    private Button mCancelButton;

    // Member variable for the notification manager
    private NotificationManager mNotificationManager;

    // Member variable for the notification receiver
    private NotificationReceiver mReceiver = new NotificationReceiver();

    // Request code for notification permission
    private static final int NOTIFICATION_PERMISSION_REQUEST_CODE = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the buttons
        mNotifyButton = findViewById(R.id.notify);
        mUpdateButton = findViewById(R.id.update);
        mCancelButton = findViewById(R.id.cancel);
        
        // Check and request notification permission for Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotificationPermission();
        }

        // Set up the click listeners for all the buttons
        mNotifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendNotification();
            }
        });

        mUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateNotification();
            }
        });

        mCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelNotification();
            }
        });

        // Set the initial state of the buttons
        setNotificationButtonState(true, false, false);

        // Register the broadcast receiver with explicit intent
        try {
            IntentFilter intentFilter = new IntentFilter(ACTION_UPDATE_NOTIFICATION);
            intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
            registerReceiver(mReceiver, intentFilter);
        } catch (Exception e) {
            // Handle registration error
        }

        // Call the method to create the notification channel
        createNotificationChannel();
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(mReceiver);
        } catch (Exception e) {
            // Receiver might not be registered
        }
        super.onDestroy();
    }

    /**
     * Creates a Notification channel, for OREO and higher.
     */
    public void createNotificationChannel() {
        try {
            mNotificationManager = (NotificationManager)
                    getSystemService(NOTIFICATION_SERVICE);

            // Check if the Android Version is greater than or equal to Oreo
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Check if channel already exists
                NotificationChannel existingChannel = mNotificationManager.getNotificationChannel(PRIMARY_CHANNEL_ID);
                if (existingChannel == null) {
                    // Create the NotificationChannel with all the parameters
                    NotificationChannel notificationChannel = new NotificationChannel(
                            PRIMARY_CHANNEL_ID,
                            "Mascot Notification",
                            NotificationManager.IMPORTANCE_HIGH);

                    // Configure the notification channel
                    notificationChannel.enableLights(true);
                    notificationChannel.setLightColor(Color.RED);
                    notificationChannel.enableVibration(true);
                    notificationChannel.setDescription("Notification from Mascot");

                    mNotificationManager.createNotificationChannel(notificationChannel);
                }
            }
        } catch (Exception e) {
            // Handle channel creation error
        }
    }

    /**
     * Helper method that builds the notification.
     *
     * @return NotificationCompat.Builder: notification builder
     */
    private NotificationCompat.Builder getNotificationBuilder() {
        try {
            // Create an explicit intent for the MainActivity
            Intent notificationIntent = new Intent(this, MainActivity.class);
            notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

            // Create a PendingIntent to be fired when the notification is clicked
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent notificationPendingIntent = PendingIntent.getActivity(
                    this,
                    NOTIFICATION_ID,
                    notificationIntent,
                    flags);

            // Build the notification
            NotificationCompat.Builder notifyBuilder = new NotificationCompat.Builder(this, PRIMARY_CHANNEL_ID)
                    .setContentTitle("You've been notified!")
                    .setContentText("This is your notification text.")
                    .setSmallIcon(R.drawable.ic_android)
                    .setContentIntent(notificationPendingIntent)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setDefaults(NotificationCompat.DEFAULT_ALL);

            return notifyBuilder;
        } catch (Exception e) {
            // Fallback if there's an error
            return new NotificationCompat.Builder(this, PRIMARY_CHANNEL_ID)
                    .setContentTitle("Notification")
                    .setContentText("Simple notification")
                    .setSmallIcon(android.R.drawable.ic_dialog_info);
        }
    }

    /**
     * Sends the notification
     */
    public void sendNotification() {
        try {
            // Create an intent for the update action
            Intent updateIntent = new Intent(ACTION_UPDATE_NOTIFICATION);
            updateIntent.setPackage(getPackageName()); // Make intent explicit
            updateIntent.addCategory(Intent.CATEGORY_DEFAULT);

            // Create a PendingIntent for the update action
            int broadcastFlags = PendingIntent.FLAG_ONE_SHOT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                broadcastFlags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent updatePendingIntent = PendingIntent.getBroadcast(
                    this,
                    NOTIFICATION_ID,
                    updateIntent,
                    broadcastFlags);

            // Build the notification with all the parameters
            NotificationCompat.Builder notifyBuilder = getNotificationBuilder();

            // Add the action button using the pending intent
            notifyBuilder.addAction(R.drawable.ic_update, "Update Notification", updatePendingIntent);

            // Ensure notification manager is initialized
            if (mNotificationManager == null) {
                createNotificationChannel();
            }

            // Deliver the notification
            if (mNotificationManager != null) {
                mNotificationManager.notify(NOTIFICATION_ID, notifyBuilder.build());
                // Set the button states
                setNotificationButtonState(false, true, true);
            }
        } catch (Exception e) {
            // Handle notification error
            // Keep the notify button enabled in case of error
            setNotificationButtonState(true, false, false);
        }
    }

    /**
     * Updates the existing notification
     */
    public void updateNotification() {
        // Build the notification with all the parameters using the helper method
        NotificationCompat.Builder notifyBuilder = getNotificationBuilder();
        
        try {
            // Convert the drawable resource to a bitmap
            Bitmap androidImage = BitmapFactory.decodeResource(
                    getResources(),
                    R.drawable.mascot_1);
            
            // Update the notification style to BigPictureStyle
            notifyBuilder.setStyle(new NotificationCompat.BigPictureStyle()
                    .bigPicture(androidImage)
                    .setBigContentTitle("Notification Updated!"));
        } catch (Exception e) {
            // Fallback if image loading fails
            notifyBuilder.setContentTitle("Notification Updated!")
                         .setContentText("This is the updated notification");
        }

        // Deliver the notification
        mNotificationManager.notify(NOTIFICATION_ID, notifyBuilder.build());

        // Set the button states
        setNotificationButtonState(false, false, true);
    }

    /**
     * Cancels the notification
     */
    public void cancelNotification() {
        // Cancel the notification
        mNotificationManager.cancel(NOTIFICATION_ID);

        // Set the button states
        setNotificationButtonState(true, false, false);
    }

    /**
     * Helper method to enable/disable the buttons
     */
    void setNotificationButtonState(Boolean isNotifyEnabled,
                                    Boolean isUpdateEnabled,
                                    Boolean isCancelEnabled) {
        mNotifyButton.setEnabled(isNotifyEnabled);
        mUpdateButton.setEnabled(isUpdateEnabled);
        mCancelButton.setEnabled(isCancelEnabled);
    }
    
    /**
     * Requests notification permission for Android 13+ (API 33+)
     */
    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != 
                    android.content.pm.PackageManager.PERMISSION_GRANTED) {
                // Permission is not granted, request it
                requestPermissions(
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_REQUEST_CODE);
            }
        }
    }
    
    /**
     * Handle the permission request result
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST_CODE) {
            // If request is cancelled, the result arrays are empty
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                // Permission was granted
                createNotificationChannel();
            } else {
                // Permission denied - disable notification functionality or show explanation
                // You could show a dialog explaining why notifications are important
                // and provide a button to open app settings
            }
        }
    }

    /**
     * Broadcast receiver for the action buttons in the notification
     */
    public class NotificationReceiver extends BroadcastReceiver {

        public NotificationReceiver() {
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            updateNotification();
        }
    }
}