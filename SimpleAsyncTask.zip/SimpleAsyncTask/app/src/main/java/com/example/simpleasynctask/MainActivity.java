package com.example.simpleasynctask;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // Keys for saving the state
    private static final String TEXT_STATE = "currentText";
    private static final String PROGRESS_STATE = "progressVisibility";
    private static final String BUTTON_STATE = "buttonEnabled";

    // Member variables
    private TextView mTextView;
    private ProgressBar mProgressBar;
    private Button mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the views
        mTextView = findViewById(R.id.textView1);
        mProgressBar = findViewById(R.id.progressBar);
        mButton = findViewById(R.id.button);

        // Restore state if there is a savedInstanceState
        if (savedInstanceState != null) {
            mTextView.setText(savedInstanceState.getString(TEXT_STATE));
            mProgressBar.setVisibility(savedInstanceState.getInt(PROGRESS_STATE));
            mButton.setEnabled(savedInstanceState.getBoolean(BUTTON_STATE));
        }
    }

    /**
     * Handles the onClick for the "Start Task" button. Launches the AsyncTask
     * which performs work off of the UI thread.
     *
     * @param view The view (Button) that was clicked.
     */
    public void startTask(View view) {
        // Set the text to indicate that the task has started
        mTextView.setText(R.string.napping);
        
        // Show the progress bar
        mProgressBar.setVisibility(View.VISIBLE);
        
        // Disable the button while task is running
        mButton.setEnabled(false);

        // Start the AsyncTask
        new SimpleAsyncTask(mTextView, mProgressBar, mButton).execute();
    }

    /**
     * Saves the contents of the TextView to restore on configuration change.
     *
     * @param outState The bundle in which the state of the activity is saved
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // Save the state of the views
        outState.putString(TEXT_STATE, mTextView.getText().toString());
        outState.putInt(PROGRESS_STATE, mProgressBar.getVisibility());
        outState.putBoolean(BUTTON_STATE, mButton.isEnabled());
    }
}