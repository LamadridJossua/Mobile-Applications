package com.example.simpleasynctask;

import android.os.AsyncTask;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.Random;

/**
 * AsyncTask implementation that performs a task in the background.
 */
public class SimpleAsyncTask extends AsyncTask<Void, Integer, String> {

    // Weak references to views so we don't leak memory
    private WeakReference<TextView> mTextView;
    private WeakReference<ProgressBar> mProgressBar;
    private WeakReference<Button> mButton;
    
    // Constants for progress updates
    private static final int MAX_PROGRESS = 100;
    private static final int PROGRESS_INCREMENT = 10;

    /**
     * Constructor that accepts the views to update
     * @param tv The TextView instance to update
     * @param pb The ProgressBar instance to update
     * @param btn The Button instance to update
     */
    public SimpleAsyncTask(TextView tv, ProgressBar pb, Button btn) {
        mTextView = new WeakReference<>(tv);
        mProgressBar = new WeakReference<>(pb);
        mButton = new WeakReference<>(btn);
    }

    /**
     * Called before doInBackground to set up the task
     */
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        
        // Get references to the views
        ProgressBar pb = mProgressBar.get();
        
        // Configure progress bar if it exists
        if (pb != null) {
            pb.setIndeterminate(false);
            pb.setMax(MAX_PROGRESS);
            pb.setProgress(0);
        }
    }
    
    /**
     * Updates the progress during the background operation
     * @param values The progress values
     */
    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        
        // Get a reference to the ProgressBar
        ProgressBar pb = mProgressBar.get();
        
        // Update the progress bar if it exists
        if (pb != null && values.length > 0) {
            pb.setProgress(values[0]);
        }
    }

    /**
     * The work to be done in the background thread
     * @param voids No parameters are passed to this AsyncTask
     * @return Returns a String that will be displayed in the TextView
     */
    @Override
    protected String doInBackground(Void... voids) {
        // Generate a random number between 5 and 15 (to ensure task runs long enough to see progress)
        Random r = new Random();
        int n = r.nextInt(11) + 5;

        // Make the task take long enough that we have time to see the progress
        int totalSleepTime = n * 200;
        int sleepInterval = totalSleepTime / (MAX_PROGRESS / PROGRESS_INCREMENT);
        
        // Sleep in intervals and update progress
        for (int i = 0; i <= MAX_PROGRESS; i += PROGRESS_INCREMENT) {
            try {
                Thread.sleep(sleepInterval);
                publishProgress(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Return a String result
        return "Task completed after " + totalSleepTime + " milliseconds!";
    }

    /**
     * Updates the views with the result
     * @param result The result String returned from doInBackground()
     */
    @Override
    protected void onPostExecute(String result) {
        // Get references to the views
        TextView tv = mTextView.get();
        ProgressBar pb = mProgressBar.get();
        Button btn = mButton.get();

        // Update the views if they still exist
        if (tv != null) {
            tv.setText(result);
        }
        
        if (pb != null) {
            pb.setVisibility(View.INVISIBLE);
        }
        
        if (btn != null) {
            btn.setEnabled(true);
        }
    }
}