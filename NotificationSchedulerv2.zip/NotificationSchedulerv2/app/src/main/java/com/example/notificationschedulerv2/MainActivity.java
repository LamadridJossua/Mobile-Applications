package com.example.notificationschedulerv2;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import androidx.appcompat.widget.SwitchCompat;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int JOB_ID = 0;
    private JobScheduler mScheduler;

    // UI Components
    private RadioGroup networkOptions;
    private SwitchCompat mDeviceIdle;
    private SwitchCompat mDeviceCharging;
    private SeekBar mSeekBar;
    private TextView seekBarProgress;
    
    // Permission request launcher
    private ActivityResultLauncher<String> requestPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        initializePermissionLauncher();
        restoreState(savedInstanceState);
        setupSeekBar();
        checkNotificationPermission();
    }

    private void initializeViews() {
        try {
            networkOptions = findViewById(R.id.networkOptions);
            mDeviceIdle = findViewById(R.id.idleSwitch);
            mDeviceCharging = findViewById(R.id.chargingSwitch);
            mSeekBar = findViewById(R.id.seekBar);
            seekBarProgress = findViewById(R.id.seekBarProgress);

            if (networkOptions == null || mDeviceIdle == null || 
                mDeviceCharging == null || mSeekBar == null || seekBarProgress == null) {
                throw new IllegalStateException("Required views not found in layout");
            }

            // Set maximum value for SeekBar (e.g., 1 hour)
            mSeekBar.setMax(3600);
        } catch (Exception e) {
            Log.e(TAG, "Error initializing views", e);
            Toast.makeText(this, "Error initializing UI", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initializePermissionLauncher() {
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show();
                    } else {
                        if (!shouldShowRequestPermissionRationale(android.Manifest.permission.POST_NOTIFICATIONS)) {
                            // Permission permanently denied
                            Toast.makeText(this, 
                                "Notification permission denied. Please enable in Settings.", 
                                Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(this, 
                                "Notification permission denied. Notifications won't be shown.", 
                                Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void restoreState(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            mSeekBar.setProgress(savedInstanceState.getInt("seekBarProgress", 0));
            mDeviceIdle.setChecked(savedInstanceState.getBoolean("deviceIdle", false));
            mDeviceCharging.setChecked(savedInstanceState.getBoolean("deviceCharging", false));
            int networkOption = savedInstanceState.getInt("networkOption", -1);
            if (networkOption != -1) {
                networkOptions.check(networkOption);
            }
        }
    }

    private void setupSeekBar() {
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress > 0) {
                    seekBarProgress.setText(getString(R.string.seconds, progress));
                } else {
                    seekBarProgress.setText(R.string.not_set);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("seekBarProgress", mSeekBar.getProgress());
        outState.putBoolean("deviceIdle", mDeviceIdle.isChecked());
        outState.putBoolean("deviceCharging", mDeviceCharging.isChecked());
        outState.putInt("networkOption", networkOptions.getCheckedRadioButtonId());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mScheduler != null) {
            mScheduler.cancelAll();
            mScheduler = null;
        }
    }

    private boolean validateJobConstraints(int networkOption, boolean deviceIdle, 
                                        boolean deviceCharging, int seekBarValue) {
        // Check for impossible combinations
        if (deviceIdle && deviceCharging) {
            Toast.makeText(this, "Cannot require both idle and charging", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Validate seekBar value
        if (seekBarValue > 0 && seekBarValue < 15) {
            Toast.makeText(this, "Minimum delay must be at least 15 seconds", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    public void scheduleJob(View view) {
        if (!checkNotificationPermission()) {
            return;
        }

        // Get the selected network option
        int selectedNetworkID = networkOptions.getCheckedRadioButtonId();
        int selectedNetworkOption = JobInfo.NETWORK_TYPE_NONE;

        if (selectedNetworkID == R.id.noNetwork) {
            selectedNetworkOption = JobInfo.NETWORK_TYPE_NONE;
        } else if (selectedNetworkID == R.id.anyNetwork) {
            selectedNetworkOption = JobInfo.NETWORK_TYPE_ANY;
        } else if (selectedNetworkID == R.id.wifiNetwork) {
            selectedNetworkOption = JobInfo.NETWORK_TYPE_UNMETERED;
        }

        // Get the scheduler instance
        if (mScheduler == null) {
            try {
                mScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
                if (mScheduler == null) {
                    Toast.makeText(this, "JobScheduler service not available", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (Exception e) {
                Log.e(TAG, "Error initializing JobScheduler", e);
                Toast.makeText(this, "Error initializing JobScheduler: " + e.getMessage(), 
                    Toast.LENGTH_SHORT).show();
                return;
            }
        }

        // Get the SeekBar's progress
        int seekBarInteger = mSeekBar.getProgress();
        boolean seekBarSet = seekBarInteger > 0;

        // Validate constraints
        if (!validateJobConstraints(selectedNetworkOption, mDeviceIdle.isChecked(), 
            mDeviceCharging.isChecked(), seekBarInteger)) {
            return;
        }

        // Create the JobInfo object with specified constraints
        ComponentName serviceName = new ComponentName(getPackageName(), 
            NotificationJobService.class.getName());
        JobInfo.Builder builder = new JobInfo.Builder(JOB_ID, serviceName);

        try {
            // Only set network type if it's not NONE
            if (selectedNetworkOption != JobInfo.NETWORK_TYPE_NONE) {
                builder.setRequiredNetworkType(selectedNetworkOption);
            }

            // Add device idle constraint if switch exists and is selected
            if (mDeviceIdle.isChecked()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    builder.setRequiresDeviceIdle(true);
                } else {
                    Toast.makeText(this, "Device idle not supported on this Android version", 
                        Toast.LENGTH_SHORT).show();
                    mDeviceIdle.setChecked(false);
                }
            }

            // Add charging constraint if switch exists and is selected
            if (mDeviceCharging.isChecked()) {
                builder.setRequiresCharging(true);
            }

            // Add override deadline if set
            if (seekBarSet) {
                builder.setOverrideDeadline(seekBarInteger * 1000L);
            }

            // Check if at least one constraint is set
            boolean constraintSet = (selectedNetworkOption != JobInfo.NETWORK_TYPE_NONE)
                    || mDeviceIdle.isChecked()
                    || mDeviceCharging.isChecked()
                    || seekBarSet;

            if (constraintSet) {
                // Schedule the job and notify the user
                JobInfo myJobInfo = builder.build();
                int result = mScheduler.schedule(myJobInfo);
                if (result == JobScheduler.RESULT_SUCCESS) {
                    Toast.makeText(this, R.string.job_scheduled, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Failed to schedule job", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, R.string.constraint_needed, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error scheduling job", e);
            Toast.makeText(this, "Error scheduling job: " + e.getMessage(), 
                Toast.LENGTH_SHORT).show();
        }
    }

    public void cancelJobs(View view) {
        if (mScheduler != null) {
            try {
                mScheduler.cancelAll();
                mScheduler = null;
                Toast.makeText(this, R.string.jobs_canceled, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e(TAG, "Error canceling jobs", e);
                Toast.makeText(this, "Error canceling jobs: " + e.getMessage(), 
                    Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    private boolean checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, 
                android.Manifest.permission.POST_NOTIFICATIONS) != 
                PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS);
                return false;
            }
        }
        return true;
    }
}